<html>
  <head>
 
    <title>TUP</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  </head>
  <body>
   
  <div class="header">
  <h1>GENERIC DOCUMENT REQUEST MANAGEMENT</h1>
   </div>

  <div class="image">
  <img src="image/bg2.png" alt="">
  </div>
  
  <div class="req">
  <button class="btn" onclick="window.location.href='request.php'"><i class="fa fa-Book"></i> REQUEST DOCUMENT HERE</button>

  <div class="track">
  <button class="btn" onclick="window.location.href='track.php'"><i class="fa fa-truck"></i> TRACK YOUR DOCUMENT HERE</button>
  </div>
  
  </body>
</html>
