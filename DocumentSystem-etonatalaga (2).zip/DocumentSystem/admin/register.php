<!-- <form action="authcode.php" method="POST">
                    <div class="mb-2">
                        <label for="exampleInputEmail1" class="form-label">Name</label>
                        <input type="text" name="adminname" class="form-control" required placeholder="Enter your name">
                       
                    </div>                
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" name="adminemail" class="form-control" required placeholder="Enter your email" id="exampleInputEmail1" aria-describedby="emailHelp">
                        
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" name="adminpassword" class="form-control" required placeholder="Enter Password" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="admincpassword" class="form-control" id="exampleInputPassword1" required placeholder="Confirm Password">
                    </div>
                    
                    <button type="submit" name="adminregister_btn" class="btn btn-primary">Register</button>
</form> -->
<!DOCTYPE html>
<htmL>
  <head>
 
    <title>TUP</title>
    <link rel="stylesheet" href="register.css">
  </head>
  <body>
    <div class="center">
    
      <h1>REGISTER</h1>

      <form action="authcode.php" method="post">
        <div class="txt_field">
          <input type="text" placeholder="Enter your Name" name="adminname">
          <span></span>
          <label>Name</label>
        </div>
        <div class="txt_field">
          <input type="text" placeholder="Enter your Email" name="adminemail">
          <span></span>
          <label>Email Address</label>
        </div>
        <div class="txt_field">
          <input type="password"placeholder="Enter your Password" name="adminpassword">
          <span></span>
          <label>Password</label>
        </div>
        <div class="txt_field">
          <input type="password" placeholder="Confirm password" name="admincpassword" >
          <span></span>
          <label>Confirm Password</label>
        </div>
        <input type="submit" value="Register" name="adminregister_btn">
    
      </form>
    </div>

  </body>
</html>

