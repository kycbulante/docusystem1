<!DOCTYPE html>
<htmL>
  <head>
 
    <title>TUP</title>
    <link rel="stylesheet" href="loginpage.css">
  </head>
  <body>
    
    <h2> &nbsp &nbsp&nbsp GENERIC DOCUMENT <br> REQUEST MANAGEMENT</h2>
    <div class="center">
    
      <h1>LOGIN</h1>

      <form action="authcode.php" method="post">
        <div class="txt_field">
          <input type="text" name="email" >
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password" >
          <span></span>
          <label>Password</label>
        </div>
       <!--  kapang dadagdagan ng forgot password <div class="pass">Forgot Password?</div> -->
        <input type="submit" value="Sign In" name="adminlogin_btn">
        <!-- kapag gagawa account  -->
          <a href="register.php">Register</a>
      </form>
    </div>

  </body>
</html>
