<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="editpages.css">
    <link rel="stylesheet" href="css/overall.css">
    <title>Edit Document</title>
</head>
<body>
  <div class="header">
    <div class="Track-Document">
  <img src="../image/logorequest.png" alt="Logo" class="logo">
    Edit Document
    <a href="tablepage.php">Back</a>
</div>

      </div>
<?php
session_start();
include('../connect/connect.php');
if(!isset($_SESSION['admin']))
{
  echo"<script>alert('Please login first')</script>";
  echo"<script>window.open('loginpage.php','_self')</script>";
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    global $con;
    $query = "SELECT * FROM requests WHERE id ='$id'";
    $query_run = mysqli_query($con, $query);
}

                    if(mysqli_num_rows($query_run)>0)
                    {

                        $data = mysqli_fetch_array($query_run);}
                    ?> 
                    <div class="container">
                    <div class="heading">
                      EDIT DOCUMENT
                    </div>
                     <form action="code.php" method="POST">
                     <div class="card-details">
                        <input type="hidden" name="id" value="<?= $data['id']; ?>">  
                        <div class="card-box">
                            <div class="col-md-12">
                                        <label for="">school_id</label>
                                        <input type="text" value="<?= $data['school_id']; ?>" class="form-control" required name="school_id" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">Name</label>
                                    <input type="text" value="<?= $data['name']; ?>" class="form-control" required name="name" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">course</label>
                                    <input type="text" value="<?= $data['course']; ?>" class="form-control" required name="course" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">department</label>
                                    <input type="text" value="<?= $data['department']; ?>" class="form-control" required name="department" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">   
                        <div class="col-md-12">
                                    <label for="">number</label>
                                    <input type="text" value="<?= $data['number']; ?>" class="form-control" required name="number" placeholder="Enter Product Name">
                                </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">email</label>
                                    <input type="text" value="<?= $data['email']; ?>" class="form-control" required name="email" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">document</label>
                                    <input type="text" value="<?= $data['document']; ?>" class="form-control" required name="document" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box"> 
                            <div class="col-md-12">
                                    <label for="">purpose</label>
                                    <input type="text" value="<?= $data['purpose']; ?>" class="form-control" required name="purpose" placeholder="Enter Product Name">
                                </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">quantity</label>
                                    <input type="text" value="<?= $data['quantity']; ?>" class="form-control" required name="quantity" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">tracking_id</label>
                                    <input type="text" value="<?= $data['tracking_id']; ?>" class="form-control" required name="tracking_id" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="col-md-12">
                                    <label for="">amount</label>
                                    <input type="text" value="<?= $data['amount']; ?>" class="form-control" required name="amount" placeholder="Enter Product Name">
                            </div>
                        </div>
                        <div class="card-box">
                                <div class="col-md-12">
                                    <label for="">status</label>
                                    <select name = "status"class="form-select" >

                                    <option selected><?= $data['status']; ?></option>
                                    <option>Pending</option>
                                    <option>Approved</option>
                                    <option>Cancelled</option>
                            </select>   
                                </div>
                        </div>

                                <div class="col-md-12">
                                    <div class="button1">
                                    <input type="submit" class="btn btn-primary" name="update_details_btn" value="Update">
                                    </div>
                                </div>
                        </form>
                    </div>
                    </div>
                    <?php
                //     }
                //     else
                //     {
                //         echo"Category not found";
                //     }



                // }
                // else
                // {
                //     echo "id missing from url";
                // }
                
            ?>