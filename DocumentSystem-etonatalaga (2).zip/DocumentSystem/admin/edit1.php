<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <link rel="stylesheet" href="../requeststyle1.css">
    <link rel="stylesheet" href="../style1.css">
  <title>TUP REQUEST SYSTEM</title>
</head>
<body>



<nav id="navbar-1" class="navbar navbar-expand-md navbar-dark bg-dark sticky-top">
    
        <div class="container-fluid">

          <a class="navbar-brand ps-2 " id="brandlogo">
            <img src="../image/bg2.png" width="80" height="80" class="img-responsive d-print-inline-block h-auto d-inline-block">
          </a>
          <a class="navbar-item mx-auto text-decoration-none" id="navtit" aria-current="page">
                   <h1 id="title" style="font-family: 'Poppins', sans-serif;">EDIT DOCUMENT</h1>
          </a>
          <button class="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

          <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">

        
         <ul class="navbar-nav"  >
            <li class="nav-item">
                <a class="nav-link " aria-current="page" href="index.php"><i class="fa-sharp fa-solid fa-arrow-left fa-lg"></i> BACK</a>
              </li>
            </ul>
        
          


          </div>
            
        </div>
</nav>
<?php
session_start();
include('../connect/connect.php');
if(!isset($_SESSION['admin']))
{
  echo"<script>alert('Please login first')</script>";
  echo"<script>window.open('loginpage.php','_self')</script>";
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    global $con;
    $query = "SELECT * FROM requests WHERE id ='$id'";
    $query_run = mysqli_query($con, $query);
}

                    if(mysqli_num_rows($query_run)>0)
                    {

                        $data = mysqli_fetch_array($query_run);}
                    ?> 


<div class="body1 d-flex align-items-center justify-content-center flex-grow-1">
        
<div class="container" style="margin-bottom:200px;">
        <div class="heading">
           EDIT DOCUMENT 
        </div>

        <form class="row g-3" action="code.php" method="POST">

      <div class="col-md-6">
      <label for="">school_id</label>
    <input type="text" value="<?= $data['school_id']; ?>" class="form-control" required name="school_id" placeholder="Enter Product Name">
      </div>

      <div class="col-md-6">
      <label for="">Name</label>
                                    <input type="text" value="<?= $data['name']; ?>" class="form-control" required name="name" placeholder="Enter Product Name">
      </div>

      <div class="col-12">
        <label for="">course</label>
                                    <input type="text" value="<?= $data['course']; ?>" class="form-control" required name="course" placeholder="Enter Product Name">
        </div>

        <div class="col-12">

                <label for="">department</label>
  <input type="text" value="<?= $data['department']; ?>" class="form-control" required name="department" placeholder="Enter Product Name">
  </div>



  <div class="col-md-4">
    <label for="inputPhone" class="form-label">Phone Number</label>
    <input type="text" value="<?= $data['number']; ?>" class="form-control" required name="number" placeholder="Enter Product Name">  </div>

  <div class="col-md-8">
  <label for="inputPhone" class="form-label">Email</label>
  <input type="text" value="<?= $data['email']; ?>" class="form-control" required name="email" placeholder="Enter Product Name">
  </div>

  <div class="col-md-9">
    <label for="inputZip" class="form-label">Document Requested</label>
    <input type="text" value="<?= $data['document']; ?>" class="form-control" required name="document" placeholder="Enter Product Name">

  </div>

  <div class="col-md-3">
  <label class="form-label">Quantity</label>
  <input type="text" value="<?= $data['quantity']; ?>" class="form-control" required name="quantity" placeholder="Enter Product Name">

  </div>
  <div class="col-md-12">
  <label for="inputPhone" class="form-label">Reason for Requesting</label>
  <input type="text" value="<?= $data['purpose']; ?>" class="form-control" required name="purpose" placeholder="Enter Product Name">
  </div>

  <div class="col-md-4">
  <label for="inputPhone" class="form-label">Tracking</label>
  <input type="text" value="<?= $data['tracking_id']; ?>" class="form-control" required name="tracking_id" placeholder="Enter Product Name">
  </div>

  <div class="col-md-4">
  <label for="inputPhone" class="form-label">Price</label>
  <input type="text" value="<?= $data['amount']; ?>" class="form-control" required name="amount" placeholder="Enter Product Name">
  </div>

  <div class="col-md-4">
    <label for="inputZip" class="form-label">Status</label>
    <select name = "status"class="form-select" >

            <option selected><?= $data['status']; ?></option>
            <option>Pending</option>
            <option>Approved</option>
            <option>Cancelled</option>
</select>   
  </div>

  <div class="col-12  d-flex justify-content-center mt-5">
    <button  class= "btn btn-danger btn-lg" name="update_details_btn" type="submit">UPDATE</button>
  </div>

 
    </form>

    


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>