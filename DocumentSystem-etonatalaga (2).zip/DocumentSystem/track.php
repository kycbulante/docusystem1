<?php
include('./connect/connect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="trackingpage.css">
    <title>Tracking Page</title>
</head>
<body>
<div class="header">
    <div class="Track-Document">
      <img src="image/track.png" class="logo">
      Tracking
    </div>
    <div class="Menu">
    <a href="index.php" class="active">Home</a>
    <a href="request.php" >Request</a>
</div>
</div>

<img src="image/bg2.png" alt="TUP Logo" class="tup">

<div class="tracking">
    <form action="" method="POST">
                <input type="text" name="search" placeholder="Enter your Tracking ID" class="trackNum">
                <div class="button">
                <input type="submit" value="TRACK" name="search_btn">
                </div>
    </form>      
</div>


    <?php
if(isset($_POST['search_btn']))
{
    
$search = mysqli_real_escape_string($con,$_POST['search']);

$search_query = "SELECT * FROM requests WHERE tracking_id='$search'";
$search_query_run = mysqli_query($con,$search_query);

if(mysqli_num_rows($search_query_run)>0)
{
    $data = mysqli_fetch_array($search_query_run);
    
    if($data['status']=="Approved"){
    ?>
    <div >
    <h2>Document request number <?= $data['tracking_id']; ?> is ready for claiming. <br>
        Please prepare an amount of <?= $data['amount']; ?> PHP upon claiming in the registrar.</h2> 
        </div>
       <?php
    }
    else if ($data['status']=="Pending")
    {
        ?>
        <h2>Document request number <?= $data['tracking_id']; ?> is still on process.</h2> 
        <?php
    }
    else if ($data['status']=="Cancelled")
    {
        ?>
        <h2>Document request number <?= $data['tracking_id']; ?> was not approved. Please recheck your details and apply again.</h2> 
        <?php
    }
}
else{
    ?>
    <p> No results</p>
    <?php
}
}
?>
</body>
</html>
