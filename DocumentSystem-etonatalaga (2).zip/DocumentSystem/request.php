<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="requeststyle.css">
    <link rel="stylesheet" href="css/overall.css">
    <title>Request Document</title>
</head>
<body>
  <div class="header">
    <div class="Track-Document">
  <img src="image/logorequest.png" alt="Logo" class="logo">
    Document Request
</div>
      <div class="Menu">
        <a href="index.php" class="active">Home</a>
        <a href="track.php" >Track</a>
      </div>
      </div>
    <div class="container">
        <div class="heading">
            Input Details
        </div>
        
        <form action="code.php" method="POST">
            <div class="card-details">
                <div class="card-box">
                    
                    <input type="text"  name="name" placeholder="Full Name">
                </div>
                <div class="card-box">
                    <input type="text" name="id" required placeholder="ID (Ex. TUPM 00-0000)">
                </div>
                <div class="card-box">                    
                    <select name = "course" class="form-select" >
                                <option selected>Bachelor in Graphics Technology Mechanical Drafting Technology</option>
                                <option>Bachelor in Graphics Technology Industrial Design</option>
                                <option>Bachelor in Graphics Technology Architecture Technology</option>
                                <option>Bachelor of Science in Architecture</option>
                                <option>Bachelor of Science in Civil Engineering</option>
                                <option>Bachelor of Science in Civil Engineering (Non-STEM)</option>
                                <option>Bachelor of Science in Electrical Engineering</option>
                                <option>Bachelor of Science in Electrical Engineering (Non-STEM)</option>
                                <option>Bachelor of Science in Electronics Engineering</option>
                                <option>Bachelor of Science in Electronics Engineering (Non Stem)</option>
                                <option>Bachelor of Science in Mechanical Engineering</option>
                                <option>Bachelor of Science in Mechanical Engineering (Non- STEM)</option>
                                <option>Bachelor of Science in Mechanical Engineering</option>

                        </select> 
                        <!-- COLLEGE OF INDUSTRIAL EDUCATION
Bachelor of Science in Industrial Education
Information and Communication Technology Home Economics
Industrial Arts
Bachelor of Technical-Vocational Teacher Education
Electrical Technology
Computer Programming
Animation
Animation
Electronics Technology
Heating, Ventilation and Air Conditioning/Refrigeration
Food Service Management
Beauty Care and Wellness
Fashion Garments Technology
Certificate Program for Professional Teacher
 COLLEGE OF INDUSTRIAL TECHNOLOGY Bachelor of Engineering Technology Mechanical Technology
Railway Technology
Mechanical Technology option in Automotive Engineering Technology
Mechanical Technology option in Heating, Ventilation and Air Conditioning/Refrigeration
Mechanical Technology option in Power Plant Engineering Technology (Non-Stem)
Mechanical Technology option in Power Plant Engineering Technology
Mechanical Technology option in Heating, Ventilation and Air Conditioning/Refrigeration (Non-Stem) Mechanical Technology option in Automotive Technology (Non-Stem)
Construction Technology
Construction Technology (Non-Stem)
Electronics Technology
Electronics Technology (Non-Stem)
Electronic Communications Technology
Electronic Communications Technology (Non-Stem) Computer Engineering Technology
Computer Engineering Technology (Non-Stem) Print Media Technology (Non-Stem)
Print Media
Bachelor of Engineering Technology major in Electrical Technology
Bachelor of Engineering Tool
Bachelor of Science in Hotel and Restaurant Management Bachelor of Technology
Mechanical Technology (Non-Stem) Mechanical Engineering Technology Electrical Engineering Technology
Bachelor of Technology major in Apparel and Fashion Technology
Bachelor of Technology major in Nutrition and Food Technology
COLLEGE OF LIBERAL ARTS
Bachelor of Arts in Management (Laderized Program) Industrial Management
Bachelor of Arts in Management major in Industrial Management
Bachelor of Science in Entrepreneurship (ABM) Bachelor of Science in Entrepreneurship (Non ABM)
COLLEGE OF SCIENCE
12
Bachelor of Applied Science in Laboratory Technology Bachelor of Applied Science in Laboratory Technology (Non-STEM)
Bachelor of Science in Computer Science
Bachelor of Science in Computer Science (Non-STEM) Bachelor of Science in Environmental Science
Bachelor of Science in Environmental Science (Non- STEM)
Bachelor of Science in Information System
Bachelor of Science in Information System (Non-STEM) Bachelor of Science in Information Technology Bachelor of Science in Information Technology (Non- STEM)-->

                </div>
                <div class="card-box">                    
                        
                        <select name = "department"class="form-select" >
                                <option selected>COLLEGE OF ARCHITECTURE AND FINE ARTS</option>
                                <option>COE</option>
                                <option>CIE</option>
                                <option>CIT</option>
                                <option>CLA</option>
                                <option>COS</option>
                        </select>     
                </div>
                <div class="card-box-phone">
                    <input type="phone" name="number" required placeholder="Phone number">
                </div>
                <div class="card-box-email">  
                    <input type="email" name="email" required placeholder="Email">
                </div>
                <div class="card-box-document-request">  
                    <select name = "document"class="form-select" >
                                <option>Form 137</option>
                                <option>Form 138</option>
                                <option>Certificate of Graduation</option>
                                <option>Certificate of Registration</option>
                                <option>Good Moral</option>
                                <option selected>Transcript of Records</option>
                        </select> 
                </div>
                <div class="card-box-quantity">
                    <p> </p>
                </div>
                <div class="card-box-quantity">  
                    <input type="number" 
                    required placeholder="Quantity" name="quantity" min="1" max="10">
                </div>
                <div class="card-box-quantity">
                    <p> </p>
                </div>
                <div class="card-box-quantity">  
                <p><br><br> </p>
                </div>
                
                
                
            </div>
            <div class="card-box-document-purpose">
                <input type="text" 
                required placeholder="Document Purpose" name="purpose">
            </div>
            <div class="button1">
        <input type="submit" name="request_btn" value="Request" class="buttontype">
        <!-- <button type="submit" name="request_btn" class="btn btn-primary">Register</button> -->
    </div>
            
        </form>
        
    </div>
    
    <div class="text-track">
        TRACK YOUR DOCUMENT <a href="track.php" >HERE</a>!
    </div>
</body>

</html>